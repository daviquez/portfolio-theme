<?php wp_footer(); ?>
<footer class="d-md-none w-100 row">
    <div class="col-12 text-right px-5 text-muted">
        <p><strong><?php echo get_bloginfo() ?></strong> © <?php date("Y") ?> | Online portfolio</p>
    </div>
</footer>
</main>
</body>
</html>