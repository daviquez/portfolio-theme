<?php

// POST THUMBNAILS
add_theme_support('post-thumbnails');
add_image_size('smallest', 300, 300, true);// true is for hard cutting
add_image_size('largest', 800, 800, true);

// MENU
add_theme_support('menus');
// WP MEDIA
add_theme_support('wp-media');